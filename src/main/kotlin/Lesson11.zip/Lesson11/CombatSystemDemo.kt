//package Lesson11
//
//class CombatSystemDemo {
//    fun simulateFight(){
//        EventBus.post(GameEvent.DamageDealt("Oleg", "Sahar", 10))
//        EventBus.post(GameEvent.DamageDealt("Sahar", "Oleg", 5))
//
//        EventBus.post(GameEvent.EffectApplied("Oleg", "Яд"))
//
//        EventBus.post(GameEvent.CharacterDied("Sahar", "Oleg"))
//    }
//}